<?php

return [
    'name' => 'Simulator',
];
