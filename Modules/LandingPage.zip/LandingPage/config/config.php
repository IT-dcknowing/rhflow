<?php

return [
    'name' => 'LandingPage',
];
