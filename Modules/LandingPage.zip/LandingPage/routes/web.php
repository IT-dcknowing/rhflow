<?php

use Illuminate\Support\Facades\Route;
use Modules\LandingPage\Http\Controllers\LandingPageController;

Route::middleware(['web'])->group(function () {
    Route::resource('landingpages', 'Modules\LandingPage\Http\Controllers\LandingPageController')->names('landingpage');
    Route::post('contact', 'Modules\LandingPage\Http\Controllers\LandingPageController@storeContact')->name('contact.store');
    Route::get('contact', 'Modules\LandingPage\Http\Controllers\LandingPageController@showContact')->name('contact');
    Route::get('privacy', 'Modules\LandingPage\Http\Controllers\LandingPageController@showPrivacy')->name('privacy');
    // Routes d'inscription et de commande
    Route::get('register', 'Modules\LandingPage\Http\Controllers\LandingPageController@showRegistration')->name('register');
    Route::post('register', 'Modules\LandingPage\Http\Controllers\LandingPageController@register')->name('register.store');
    Route::get('order/payment/{order}', 'Modules\LandingPage\Http\Controllers\LandingPageController@showPayment')->name('order.payment');
    Route::post('order/success/{order}', 'Modules\LandingPage\Http\Controllers\LandingPageController@orderSuccess')->name('order.success');
    Route::get('order/success/{order}', 'Modules\LandingPage\Http\Controllers\LandingPageController@showOrderSuccess')->name('order.success.view'); 
});
    
