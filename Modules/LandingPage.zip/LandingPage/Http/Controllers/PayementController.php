<?php

namespace Modules\LandingPage\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Plan;
use App\Models\Order;
use Illuminate\Support\Str;

class PaymentController extends Controller
{
    public function initiatePayment(Request $request)
    {
        $request->validate([
            'plan_id' => 'required|exists:plans,id',
            'phone' => 'required|string|max:20',
        ]);
        $order = Order::all()->count();
        $plan = Plan::findOrFail($request->plan_id);
        $order_number = 'Commande-#' . $order + 1;
        // Créer une commande en attente
        $order = Order::create([
            'payment_reference' => 'WAVE-' . time() . '-' . Str::random(6),
            'order_number' => $order_number,
            'plan_id' => $plan->id,
            'amount' => $plan->price,
            'total_amount' => $plan->price,
            'status' => 'pending',
            'user_id' => auth()->id() ?? null,
            'payment_method' => 'wave',
            'payment_id' => null,
            'phone' => $request->phone,
        ]);

        // Rediriger vers la page de paiement Wave
        return view('landingpage::payment.wave', [
            'order' => $order,
            'plan' => $plan,
            'public_key' => config('services.wave.public_key'),
            'wave_environment' => config('services.wave.environment'),
        ]);
    }

    public function handleCallback(Request $request)
    {
        // Cette route sera appelée par Wave après le paiement
        $paymentId = $request->input('payment_id');
        $status = $request->input('status');
        
        // Ici, vous devrez vérifier le statut du paiement avec l'API Wave
        // et mettre à jour votre commande en conséquence
        
        return redirect()->route('payment.status')
            ->with('status', $status === 'success' ? 'Paiement réussi !' : 'Paiement échoué');
    }

    public function webhook(Request $request)
    {
        // Webhook pour les notifications de paiement
        $signature = $request->header('Wave-Signature');
        $payload = $request->getContent();
        
        // Valider la signature du webhook ici
        
        $data = json_decode($payload, true);
        
        // Traiter la notification de paiement
        // Mettre à jour le statut de la commande
        
        return response()->json(['status' => 'success']);
    }
}
