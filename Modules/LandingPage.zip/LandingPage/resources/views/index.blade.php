<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'RH Flow - Gestion RH')</title>
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    <script>tailwind.config={theme:{extend:{colors:{primary:'rgb(53, 149, 246)',secondary:'#64748b',accent:'#f59e0b',dark:'#1e293b'},borderRadius:{'none':'0px','sm':'4px',DEFAULT:'8px','md':'12px','lg':'16px','xl':'20px','2xl':'24px','3xl':'32px','full':'9999px','button':'8px'}}}}</script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.6.0/remixicon.min.css">
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="{{ asset('img/favicon/favicon.ico') }}">
    <style>
        :where([class^="ri-"])::before { content: "\f3c2"; }
        body {
            font-family: 'Inter', sans-serif;
        }
        .hero-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .hero-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
        .feature-card {
            transition: all 0.3s ease;
            border: 1px solid transparent;
        }
        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px -10px rgba(59, 130, 246, 0.25);
            border-color: #3b82f6;
        }
        .gradient-text {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .floating {
            animation: floating 3s ease-in-out infinite;
        }
        @keyframes floating {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }
        .stats-counter {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        }
        .custom-checkbox {
            position: relative;
            padding-left: 30px;
            cursor: pointer;
            user-select: none;
        }
        .custom-checkbox input {
            position: absolute;
            opacity: 0;
            cursor: pointer;
            height: 0;
            width: 0;
        }
        .checkmark {
            position: absolute;
            top: 0;
            left: 0;
            height: 20px;
            width: 20px;
            background-color: #fff;
            border: 2px solid #e5e7eb;
            border-radius: 4px;
        }
        .custom-checkbox:hover input ~ .checkmark {
            border-color: #1e3a8a;
        }
        .custom-checkbox input:checked ~ .checkmark {
            background-color: #1e3a8a;
            border-color: #1e3a8a;
        }
        .checkmark:after {
            content: "";
            position: absolute;
            display: none;
        }
        .custom-checkbox input:checked ~ .checkmark:after {
            display: block;
        }
        .custom-checkbox .checkmark:after {
            left: 6px;
            top: 2px;
            width: 5px;
            height: 10px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
        .custom-switch {
            position: relative;
            display: inline-block;
            width: 48px;
            height: 24px;
        }
        .custom-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .switch-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #e5e7eb;
            transition: .4s;
            border-radius: 24px;
        }
        .switch-slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        input:checked + .switch-slider {
            background-color: #1e3a8a;
        }
        input:checked + .switch-slider:before {
            transform: translateX(24px);
        }
    </style>
    <script src="https://cdn.cinetpay.com/seamless/main.js" type="text/javascript"></script>
    
    <!-- Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-TDCW7Z7RDV"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-TDCW7Z7RDV');
    </script>
</head>
<body class="bg-white">
    <!-- Header -->
    <header class="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md z-50 border-b border-gray-100">
        <div class="container mx-auto px-4">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center space-x-8">
                    <a href="{{ route('landingpage.index') }}" class="flex items-center space-x-3">
                        <img src="{{ asset('img/logos/logo-dark.png') }}" alt="RH-Flow" class="h-8 w-auto">
                        <span class="text-xl font-bold text-gray-900">RH-Flow</span>
                    </a>
                    <nav class="hidden md:flex items-center space-x-6">
                        <a href="#fonctionnalites" class="text-gray-600 hover:text-primary transition-colors font-medium">Fonctionnalités</a>
                        <a href="#avantages" class="text-gray-600 hover:text-primary transition-colors font-medium">Avantages</a>
                        <a href="#temoignages" class="text-gray-600 hover:text-primary transition-colors font-medium">Témoignages</a>
                        <a href="#tarifs" class="text-gray-600 hover:text-primary transition-colors font-medium">Tarifs</a>
                        <a href="#contact" class="text-gray-600 hover:text-primary transition-colors font-medium">Contact</a>
                    </nav>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="{{ route('login') }}" class="text-gray-600 hover:text-primary transition-colors font-medium hidden md:block">Se connecter</a>
                    <a href="{{ route('register') }}" class="bg-blue-700 text-white px-4 py-2 rounded-lg hover:bg-blue-700/90 transition-colors font-medium">Essai gratuit</a>
                    <button class="md:hidden flex items-center justify-center w-10 h-10 text-gray-700" id="mobile-menu-button">
                        <i class="ri-menu-line ri-xl"></i>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div class="hidden md:hidden bg-white border-t border-gray-100" id="mobile-menu">
            <div class="container mx-auto px-4 py-4 space-y-3">
                <a href="#fonctionnalites" class="block text-gray-600 hover:text-primary transition-colors font-medium py-2">Fonctionnalités</a>
                <a href="#avantages" class="block text-gray-600 hover:text-primary transition-colors font-medium py-2">Avantages</a>
                <a href="#temoignages" class="block text-gray-600 hover:text-primary transition-colors font-medium py-2">Témoignages</a>
                <a href="#tarifs" class="block text-gray-600 hover:text-primary transition-colors font-medium py-2">Tarifs</a>
                <a href="#contact" class="block text-gray-600 hover:text-primary transition-colors font-medium py-2">Contact</a>
                <a href="{{ route('login') }}" class="block text-gray-600 hover:text-primary transition-colors font-medium py-2">Se connecter</a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="min-h-screen pt-24 pb-16 md:pt-32 md:pb-24 relative overflow-hidden bg-gradient-to-br from-blue-700 via-blue-700 to-blue-700 flex items-center">
        <div class="absolute inset-0 bg-black/20"></div>
        <div class="container mx-auto px-4 relative z-10">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div class="text-white">
                    <div class="inline-flex items-center bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
                        <span class="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                        <span class="text-sm font-medium">Nouveau: Application mobile employé disponible </span>
                    </div>
                    <h1 class="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                        Gérez vos RH en toute 
                        <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-200 to-cyan-200">simplicité</span>
                    </h1>
                    <p class="text-xl md:text-2xl text-white/90 mb-8 leading-relaxed">
                        Automatisez la paie, les congés et les déclarations ITS,
                        CNPS et CNPS. Gain de temps garanti.
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4 mb-8">
                        <a href="#tarifs" class="bg-white text-primary px-8 py-4 rounded-button hover:bg-gray-100 transition-all duration-300 font-bold text-center shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                            Commencer gratuitement
                        </a>
                        <a href="#demo" class="bg-transparent border-2 border-white text-white px-8 py-4 rounded-button hover:bg-white hover:text-primary transition-all duration-300 font-bold text-center">
                            Demander une démo
                        </a>
                    </div>
                    <div class="flex items-center space-x-8 text-white/80">
                        <div class="flex items-center">
                            <i class="ri-check-line text-green-400 mr-2"></i>
                            <span class="text-sm">Essai 14 jours</span>
                        </div>
                        <div class="flex items-center">
                            <i class="ri-check-line text-green-400 mr-2"></i>
                            <span class="text-sm">Sans carte bancaire</span>
                        </div>
                        <div class="flex items-center">
                            <i class="ri-check-line text-green-400 mr-2"></i>
                            <span class="text-sm">Support 24/7</span>
                        </div>
                    </div>
                </div>
                <div class="relative">
                    <div class="floating scale-125 lg:scale-150">
                        <img src="{{ asset('images/im.png') }}" alt="RH-Flow Dashboard" class="rounded-2xl shadow-2xl w-full h-auto max-h-[600px] object-contain">
                    </div>
                    <div class="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-lg p-4 hidden lg:block">
                        <div class="flex items-center space-x-3">
                            <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                                <i class="ri-line-chart-line text-green-600 text-xl"></i>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Productivité</p>
                                <p class="text-xl font-bold text-gray-900">+75%</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

  

    <!-- Features Section -->
    <section id="fonctionnalites" class="py-16 md:py-24 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <div class="inline-flex items-center bg-primary/10 rounded-full px-4 py-2 mb-6">
                    <i class="ri-star-line text-primary mr-2"></i>
                    <span class="text-primary font-semibold">Fonctionnalités</span>
                </div>
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Tout ce dont vous avez besoin</h2>
                <p class="text-xl text-gray-600">Une solution complète pour gérer efficacement vos ressources humaines</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Feature 1 -->
                <div class="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div class="w-16 h-16 bg-gradient-to-br from-blue-700 to-blue-700 rounded-2xl flex items-center justify-center mb-6">
                        <i class="ri-calendar-check-line text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Gestion des congés</h3>
                    <p class="text-gray-600 mb-6">Suivi automatique des demandes, validation en un clic et calendrier partagé pour une vision claire des absences.</p>
                   
                </div>

                <!-- Feature 2 -->
                <div class="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div class="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-6">
                        <i class="ri-file-text-line text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Paie et déclarations</h3>
                    <p class="text-gray-600 mb-6">Génération automatique des bulletins, déclarations CNPS/ITS/CMU au format XML et export simplifié.</p>
                   
                </div>

                <!-- Feature 3 -->
                <div class="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div class="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center mb-6">
                        <i class="ri-team-line text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Gestion du personnel</h3>
                    <p class="text-gray-600 mb-6">Fiches collaborateurs complètes, suivi des performances, entretiens et objectifs personnalisés.</p>
                    
                </div>

                <!-- Feature 4 -->
                <div class="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div class="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6">
                        <i class="ri-smartphone-line text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Application mobile</h3>
                    <p class="text-gray-600 mb-6">Accès complet sur mobile pour vos équipes. Demandes de congés, consultation et notifications en temps réel.</p>
                    
                </div>

                <!-- Feature 5 -->
                <div class="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div class="w-16 h-16 bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-2xl flex items-center justify-center mb-6">
                        <i class="ri-shield-check-line text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Sécurité avancée</h3>
                    <p class="text-gray-600 mb-6">Données hébergées en France, chiffrement de bout en bout et conformité RGPD totale.</p>
                   
                </div>

                <!-- Feature 6 -->
                <div class="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div class="w-16 h-16 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6">
                        <i class="ri-customer-service-2-line text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Support dédié</h3>
                    <p class="text-gray-600 mb-6">Accompagnement personnalisé, formation des équipes et support technique 7j/7 par téléphone et email.</p>
                   
                </div>

                <!-- Feature 7 - Dashboard Analytics -->
                <div class="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div class="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6">
                        <i class="ri-bar-chart-box-line text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Tableau de bord analytique</h3>
                    <p class="text-gray-600 mb-6">Suivez vos indicateurs RH en temps réel avec des graphiques interactifs et des rapports personnalisés.</p>
                    
                </div>

                <!-- Feature 8 - Document Management -->
                <div class="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div class="w-16 h-16 bg-gradient-to-br from-teal-500 to-teal-600 rounded-2xl flex items-center justify-center mb-6">
                        <i class="ri-file-cloud-line text-white text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Gestion documentaire</h3>
                    <p class="text-gray-600 mb-6">Centralisez contrats, bulletins de paie et documents RH avec accès sécurisé et archivage automatique.</p>
               
                </div>
            </div>
        </div>
    </section>

   

    <!-- Why Choose Us Section -->
    <section id="avantages" class="py-16 md:py-24 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <div class="inline-flex items-center bg-accent/10 rounded-full px-4 py-2 mb-6">
                    <i class="ri-award-line text-accent mr-2"></i>
                    <span class="text-accent font-semibold">Avantages</span>
                </div>
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Pourquoi les entreprises nous choisissent</h2>
                <p class="text-xl text-gray-600">Découvrez ce qui rend RH-Flow unique sur le marché ivoirien</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
                <!-- Advantage 1 -->
                <div class="text-center group">
                    <div class="w-20 h-20 mx-auto bg-gradient-to-br from-blue-700 to-blue-700 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <i class="ri-layout-masonry-line text-white text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-3">Interface intuitive</h3>
                    <p class="text-gray-600">Design moderne et ergonomique, formation des équipes en moins d'une heure.</p>
                </div>

                <!-- Advantage 2 -->
                <div class="text-center group">
                    <div class="w-20 h-20 mx-auto bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <i class="ri-shield-check-line text-white text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-3">100% sécurisé</h3>
                    <p class="text-gray-600">Protection optimale de vos données avec un hébergement exclusivement en France.</p>
                </div>

                <!-- Advantage 3 -->
                <div class="text-center group">
                    <div class="w-20 h-20 mx-auto bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <i class="ri-headphone-line text-white text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-3">Support premium</h3>
                    <p class="text-gray-600">Accompagnement personnalisé et support technique 7j/7 inclus dans tous les plans.</p>
                </div>

                <!-- Advantage 4 -->
                <div class="text-center group">
                    <div class="w-20 h-20 mx-auto bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <i class="ri-plug-line text-white text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-3">Intégration simple</h3>
                    <p class="text-gray-600">Connectez vos outils existants et importez vos données en quelques clics.</p>
                </div>
            </div>
            
            <div class="bg-gradient-to-br from-gray-50 to-white rounded-2xl shadow-xl p-8 md:p-12">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div>
                        <div class="inline-flex items-center bg-green-100 rounded-full px-4 py-2 mb-6">
                            <span class="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                            <span class="text-green-700 font-semibold">Résultats prouvés</span>
                        </div>
                        <h3 class="text-2xl md:text-3xl font-bold text-gray-900 mb-6">
                            Une transformation digitale réussie 
                        </h3>
                        <div class="space-y-4 mb-8">
                            <div class="flex items-center">
                                <i class="ri-check-double-line text-green-500 text-xl mr-3"></i>
                                <span class="text-gray-700">75% de temps économisé sur les tâches administratives</span>
                            </div>
                            <div class="flex items-center">
                                <i class="ri-check-double-line text-green-500 text-xl mr-3"></i>
                                <span class="text-gray-700">100% de conformité avec les réglementations ivoiriennes</span>
                            </div>
                            <div class="flex items-center">
                                <i class="ri-check-double-line text-green-500 text-xl mr-3"></i>
                                <span class="text-gray-700">Satisfaction client </span>
                            </div>
                        </div>
                        <div class="flex flex-col sm:flex-row gap-4">
                            <a href="#tarifs" class="bg-primary text-white px-8 py-4 rounded-button hover:bg-primary/90 transition-colors font-bold text-center shadow-lg">
                                Démarrer maintenant
                            </a>
                            <a href="#contact" class="bg-transparent border-2 border-primary text-primary px-8 py-4 rounded-button hover:bg-primary hover:text-white transition-colors font-bold text-center">
                                Contacter un expert
                            </a>
                        </div>
                    </div>
                    <div class="relative">
                        <img src="{{ asset('images/banner-rh/banner-mobil-2.png') }}" alt="Application RH-Flow" class="rounded-2xl shadow-2xl w-full">
                        <div class="absolute -top-4 -right-4 bg-accent text-white rounded-xl shadow-lg p-3 hidden lg:block">
                            <div class="flex items-center space-x-2">
                                <i class="ri-star-fill text-yellow-300"></i>
                                <span class="font-bold">4.9/5</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section id="temoignages" class="py-16 md:py-24 bg-gradient-to-br from-gray-50 to-white">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <div class="inline-flex items-center bg-primary/10 rounded-full px-4 py-2 mb-6">
                    <i class="ri-heart-3-line text-primary mr-2"></i>
                    <span class="text-primary font-semibold">Témoignages</span>
                </div>
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Ce que nos clients disent de nous</h2>
                <p class="text-xl text-gray-600">Découvrez les expériences réelles des entreprises qui nous font confiance</p>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Main Testimonial -->
                <div class="lg:col-span-2 bg-gradient-to-br from-blue-700 to-blue-700/90 text-white p-10 rounded-3xl shadow-xl relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                    <div class="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                    
                    <div class="relative z-10">
                        <div class="flex items-center mb-6">
                            <div class="text-amber-300 flex">
                                <i class="ri-star-fill text-2xl"></i>
                                <i class="ri-star-fill text-2xl"></i>
                                <i class="ri-star-fill text-2xl"></i>
                                <i class="ri-star-fill text-2xl"></i>
                                <i class="ri-star-fill text-2xl"></i>
                            </div>
                            <span class="ml-4 text-white/80 font-medium">5.0/5.0</span>
                        </div>
                        
                        <blockquote class="text-2xl font-medium mb-8 leading-relaxed">
                            "RH-Flow a transformé complètement notre façon de gérer les RH. L'automatisation des processus nous a fait économiser 15h par semaine et nos collaborateurs sont beaucoup plus satisfaits."
                        </blockquote>
                        
                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <div class="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mr-4">
                                    <span class="text-white font-bold text-xl">FB</span>
                                </div>
                                <div>
                                    <h4 class="font-bold text-xl text-white">Franck Bakary</h4>
                                    <p class="text-white/80">Responsable RH, B-Home</p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>

                <!-- Side Testimonials -->
                <div class="space-y-6">
                    <div class="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300">
                        <div class="flex items-center mb-4">
                            <div class="text-amber-400 flex">
                                <i class="ri-star-fill text-lg"></i>
                                <i class="ri-star-fill text-lg"></i>
                                <i class="ri-star-fill text-lg"></i>
                                <i class="ri-star-fill text-lg"></i>
                                <i class="ri-star-fill text-lg"></i>
                            </div>
                        </div>
                        <p class="text-gray-700 mb-4 leading-relaxed">"L'application mobile est géniale ! Je peux tout gérer depuis mon téléphone."</p>
                        <div class="flex items-center">
                            <div class="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mr-3">
                                <span class="text-white font-bold text-sm">BK</span>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-900">Béatrice Kouakou</h4>
                                <p class="text-gray-500 text-sm">Comptable, La Fabrique</p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300">
                        <div class="flex items-center mb-4">
                            <div class="text-amber-400 flex">
                                <i class="ri-star-fill text-lg"></i>
                                <i class="ri-star-fill text-lg"></i>
                                <i class="ri-star-fill text-lg"></i>
                                <i class="ri-star-fill text-lg"></i>
                                <i class="ri-star-fill text-lg"></i>
                            </div>
                        </div>
                        <p class="text-gray-700 mb-4 leading-relaxed">"Le support client est exceptionnel, toujours disponible pour nous aider."</p>
                        <div class="flex items-center">
                            <div class="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center mr-3">
                                <span class="text-white font-bold text-sm">DK</span>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-900">Djissa Kouamé</h4>
                                <p class="text-gray-500 text-sm">Responsable RH, Leader</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

          
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="tarifs" class="py-16 md:py-24 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <div class="inline-flex items-center bg-accent/10 rounded-full px-4 py-2 mb-6">
                    <i class="ri-price-tag-3-line text-accent mr-2"></i>
                    <span class="text-accent font-semibold">Tarifs</span>
                </div>
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Des plans adaptés à votre croissance</h2>
                <p class="text-xl text-gray-600 mb-4">Choisissez la formule idéale pour votre entreprise</p>
                
                <!-- Message de réduction pour paiement annuel -->
                <div id="yearly-discount-message" class="hidden bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                    <div class="flex items-center">
                        <i class="ri-gift-line text-green-600 text-xl mr-3"></i>
                        <div>
                            <p class="text-green-800 font-semibold">Économisez jusqu'à 10% !</p>
                            <p class="text-green-600 text-sm">Profitez d'une réduction exclusive avec les abonnements annuels</p>
                        </div>
                    </div>
                </div>
                
                <!-- Boutons de filtrage Mois/Annuel -->
                <div class="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
                    <button onclick="showMonthlyPlans()" id="monthly-btn" class="bg-blue-700 text-white px-8 py-3 rounded-lg hover:bg-blue-800 transition-colors font-medium">
                        <i class="ri-calendar-line mr-2"></i>
                        Mois
                    </button>
                    <button onclick="showYearlyPlans()" id="yearly-btn" class="bg-gray-200 text-gray-700 px-8 py-3 rounded-lg hover:bg-gray-300 transition-colors font-medium">
                        <i class="ri-calendar-2-line mr-2"></i>
                        Annuel
                    </button>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8" id="plans-container">
                @foreach ($plans as $pack)
                    <div class="bg-white p-8 rounded-2xl shadow-lg border border-gray-200 hover:shadow-xl transition-all duration-300 flex flex-col relative @if($pack->popular == 1) ring-2 ring-primary ring-offset-4 @endif" data-price="{{ $pack->price }}" data-price-yearly="{{ $pack->price_yearly }}" data-id="{{ $pack->id }}">
                        @if($pack->popular == 1)
                            <div class="absolute -top-4 left-1/2 transform -translate-x-1/2">
                                <div class="bg-primary text-white px-4 py-2 rounded-full text-sm font-bold">
                                    Plus populaire
                                </div> 
                            </div>
                        @endif
                        
                        <div class="mb-6">
                            <h3 class="text-2xl font-bold text-gray-900 mb-2">{{$pack->name}}</h3>
                        </div>
                        
                        <div class="mb-6">
                            @if($pack->id == 100 || $pack->id == 102)
                                <div class="text-3xl font-bold text-gray-900">Sur mesure</div>
                                <p class="text-gray-600 mt-2">Contactez-nous pour un devis personnalisé</p>
                            @else
                                <div class="price-display">
                                    <div class="text-4xl font-bold text-gray-900 mb-2">
                                        <span class="monthly-price">{{number_format($pack->price, 0, ',', ' ')}} FCFA</span>
                                        <span class="yearly-price" style="display:none;">{{number_format($pack->price_yearly, 0, ',', ' ')}} FCFA</span>
                                        <span class="price-period monthly-period text-lg text-gray-500 font-normal">/mois</span>
                                          <span class="price-period yearly-period text-lg text-gray-500 font-normal" style="display:none;">/an</span>
                                    </div>
                                </div>
                            @endif
                        </div>
                        
                        <ul class="space-y-4 mb-8 flex-grow">
                            @php
                                $features = $pack->features;
                            @endphp
                            @foreach ($features as $feature)
                                <li class="flex items-start">
                                    <i class="ri-check-double-line text-green-500 mr-3 text-xl flex-shrink-0"></i>
                                    <span class="text-gray-700">{{ trim($feature) }}</span>
                                </li>
                            @endforeach
                        </ul>
                        
                        <div class="mt-auto">
                            @if($pack->id == 100 || $pack->id == 102)
                                <a href="#contact" class="w-full bg-gray-100 text-gray-900 px-6 py-4 rounded-button hover:bg-gray-200 transition-colors font-bold text-center block">
                                    Nous contacter
                                </a>
                            @elseif($pack->price == 0.00)
                                <a href="{{ route('register', ['plan_id' => $pack->id]) }}" class="w-full bg-blue-700 text-white px-6 py-4 rounded-button hover:bg-green-600 transition-colors font-bold text-center block shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                                    Commencer
                                </a>
                            @else
                                <a href="{{ route('register', ['plan_id' => $pack->id]) }}" class="w-full bg-blue-700 text-white px-6 py-4 rounded-button hover:bg-blue-700/90 transition-colors font-bold text-center block shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                                    Essayer gratuitement
                                </a>
                            @endif
                        </div>
                    </div>                    
                @endforeach
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section id="demo" class="py-16 md:py-24 bg-gradient-to-br from-blue-700 via-blue-700 to-blue-700 text-white relative overflow-hidden">
        <div class="absolute inset-0 bg-black/10"></div>
        <div class="container mx-auto px-4 relative z-10">
            <div class="text-center max-w-4xl mx-auto">
                <div class="inline-flex items-center bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
                    <i class="ri-rocket-2-line mr-2"></i>
                    <span class="font-medium">Démarrage rapide</span>
                </div>
                <h2 class="text-3xl md:text-5xl font-bold mb-6 leading-tight">
                    Prêt à transformer votre gestion RH ?
                </h2>
                <p class="text-xl md:text-2xl text-white/90 mb-8 leading-relaxed">
                    Rejoignez les 500+ entreprises qui font déjà confiance à RH-Flow pour optimiser leurs processus RH
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                    <a href="{{ route('register') }}" class="bg-white text-primary px-8 py-4 rounded-button hover:bg-gray-100 transition-all duration-300 font-bold text-center shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                        Commencer l'essai gratuit
                    </a>
                    <a href="#contact" class="bg-transparent border-2 border-white text-white px-8 py-4 rounded-button hover:bg-white hover:text-primary transition-all duration-300 font-bold text-center">
                        Planifier une démo
                    </a>
                </div>
                <div class="flex items-center justify-center space-x-8 text-white/80">
                    <div class="flex items-center">
                        <i class="ri-check-line text-green-400 mr-2"></i>
                        <span class="text-sm">14 jours d'essai</span>
                    </div>
                    <div class="flex items-center">
                        <i class="ri-check-line text-green-400 mr-2"></i>
                        <span class="text-sm">Aucune carte requise</span>
                    </div>
                    <div class="flex items-center">
                        <i class="ri-check-line text-green-400 mr-2"></i>
                        <span class="text-sm">Support 24/7</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-16 md:py-24 bg-gray-50">  
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <div class="inline-flex items-center bg-primary/10 rounded-full px-4 py-2 mb-6">
                    <i class="ri-question-line text-primary mr-2"></i>
                    <span class="text-primary font-semibold">FAQ</span>
                </div>
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Questions fréquentes</h2>
                <p class="text-xl text-gray-600">Tout ce que vous devez savoir sur RH-Flow</p>
            </div>
            
            <div class="max-w-3xl mx-auto">
                <div class="space-y-4">
                    <div class="faq-item bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
                        <button class="faq-button w-full px-8 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors">
                            <span class="font-semibold text-gray-900 text-lg">RH-Flow est-il adapté aux entreprises ivoiriennes ?</span>
                            <i class="ri-arrow-down-s-line text-2xl text-gray-500 transition-transform duration-300"></i>
                        </button>
                        <div class="faq-content hidden px-8 pb-6">
                            <p class="text-gray-600 leading-relaxed">Oui, RH-Flow est spécifiquement conçu pour le contexte ivoirien. Nous intégrons les réglementations locales (CNPS, ITS, CMU) et adaptons nos fonctionnalités aux besoins spécifiques des entreprises en Côte d'Ivoire.</p>
                        </div>
                    </div>
                    
                    <div class="faq-item bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
                        <button class="faq-button w-full px-8 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors">
                            <span class="font-semibold text-gray-900 text-lg">Combien de temps faut-il pour l'implémentation ?</span>
                            <i class="ri-arrow-down-s-line text-2xl text-gray-500 transition-transform duration-300"></i>
                        </button>
                        <div class="faq-content hidden px-8 pb-6">
                            <p class="text-gray-600 leading-relaxed">L'implémentation est très rapide ! En moyenne, nos clients sont opérationnels en moins de 48h. Nous vous accompagnons dans l'import de vos données et la formation de vos équipes.</p>
                        </div>
                    </div>
                    
                    <div class="faq-item bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
                        <button class="faq-button w-full px-8 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors">
                            <span class="font-semibold text-gray-900 text-lg">Mes données sont-elles sécurisées ?</span>
                            <i class="ri-arrow-down-s-line text-2xl text-gray-500 transition-transform duration-300"></i>
                        </button>
                        <div class="faq-content hidden px-8 pb-6">
                            <p class="text-gray-600 leading-relaxed">Absolument. Vos données sont hébergées en France, chiffrées de bout en bout et sauvegardées quotidiennement. Nous sommes conformes au RGPD et aux réglementations ivoiriennes sur la protection des données.</p>
                        </div>
                    </div>
                    
                    <div class="faq-item bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
                        <button class="faq-button w-full px-8 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors">
                            <span class="font-semibold text-gray-900 text-lg">Puis-je importer mes données existantes ?</span>
                            <i class="ri-arrow-down-s-line text-2xl text-gray-500 transition-transform duration-300"></i>
                        </button>
                        <div class="faq-content hidden px-8 pb-6">
                            <p class="text-gray-600 leading-relaxed">Oui, RH-Flow permet d'importer facilement vos données depuis Excel, CSV ou d'autres logiciels RH. Notre équipe vous assiste gratuitement dans le processus de migration.</p>
                        </div>
                    </div>
                    
                    <div class="faq-item bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
                        <button class="faq-button w-full px-8 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors">
                            <span class="font-semibold text-gray-900 text-lg">Quel type de support est offert ?</span>
                            <i class="ri-arrow-down-s-line text-2xl text-gray-500 transition-transform duration-300"></i>
                        </button>
                        <div class="faq-content hidden px-8 pb-6">
                            <p class="text-gray-600 leading-relaxed">Nous offrons un support complet : formation initiale, assistance technique 7j/7, documentation détaillée et webinaires mensuels. Le support est inclus dans tous nos plans sans frais supplémentaires.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-16 md:py-24 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <div class="inline-flex items-center bg-primary/10 rounded-full px-4 py-2 mb-6">
                    <i class="ri-mail-line text-primary mr-2"></i>
                    <span class="text-primary font-semibold">Contact</span>
                </div>
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Contactez-nous</h2>
                <p class="text-xl text-gray-600">Notre équipe est à votre écoute pour répondre à toutes vos questions</p>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
                <!-- Contact Form -->
                <div class="bg-gradient-to-br from-primary to-primary/90 text-white rounded-3xl p-10 shadow-xl relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                    <div class="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                    
                    <div class="relative z-10">
                        <h3 class="text-2xl font-bold mb-8">Envoyez-nous un message</h3>
                        <form action="{{ route('contact.store') }}" method="POST" class="space-y-6">
                            @csrf
                            <div>
                                <label for="name" class="block text-white/80 font-medium mb-2">Nom complet</label>
                                <input type="text" id="name" name="name" required class="w-full px-4 py-3 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-white placeholder-white/60 focus:ring-2 focus:ring-white/50 focus:border-transparent" placeholder="Votre nom">
                            </div>
                            
                            <div>
                                <label for="email" class="block text-white/80 font-medium mb-2">Email</label>
                                <input type="email" id="email" name="email" required class="w-full px-4 py-3 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-white placeholder-white/60 focus:ring-2 focus:ring-white/50 focus:border-transparent" placeholder="votre@email.com">
                            </div>
                            
                            <div>
                                <label for="company" class="block text-white/80 font-medium mb-2">Entreprise</label>
                                <input type="text" id="company" name="company" class="w-full px-4 py-3 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-white placeholder-white/60 focus:ring-2 focus:ring-white/50 focus:border-transparent" placeholder="Nom de votre entreprise">
                            </div>
                            
                            <div>
                                <label for="message" class="block text-white/80 font-medium mb-2">Message</label>
                                <textarea id="message" name="message" rows="4" required class="w-full px-4 py-3 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-white placeholder-white/60 focus:ring-2 focus:ring-white/50 focus:border-transparent" placeholder="Décrivez votre besoin..."></textarea>
                            </div>
                            
                            <button type="submit" class="w-full bg-white text-primary px-6 py-4 rounded-lg hover:bg-gray-100 transition-colors font-bold shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                                Envoyer le message
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="space-y-8">
                    <div class="bg-gray-50 rounded-2xl p-8 border border-gray-200">
                        <h3 class="text-2xl font-bold text-gray-900 mb-8">Informations de contact</h3>
                        
                        <div class="space-y-6">
                            <div class="flex items-start space-x-4">
                                <div class="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                                    <i class="ri-phone-line text-primary text-xl"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold text-gray-900 mb-1">Téléphone</h4>
                                    <p class="text-gray-600">+225 07 67 13 19 93</p>
                                    <p class="text-gray-500 text-sm">Lun-Ven 9h-18h</p>
                                </div>
                            </div>
                            
                            <div class="flex items-start space-x-4">
                                <div class="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                                    <i class="ri-mail-line text-primary text-xl"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold text-gray-900 mb-1">Email</h4>
                                    <p class="text-gray-600">infos@dcknowing.com</p>
                                    <p class="text-gray-500 text-sm">Réponse sous 24h</p>
                                </div>
                            </div>
                            
                            <div class="flex items-start space-x-4">
                                <div class="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                                    <i class="ri-map-pin-line text-primary text-xl"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold text-gray-900 mb-1">Adresse</h4>
                                    <p class="text-gray-600">Abidjan, Cocody</p>
                                    <p class="text-gray-500 text-sm">Riviera Bonoumin</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="bg-gradient-to-br from-accent/10 to-accent/5 rounded-2xl p-8 border border-accent/20">
                        <h4 class="font-bold text-gray-900 mb-4 text-xl">Besoin d'une démo ?</h4>
                        <p class="text-gray-600 mb-6">Planifiez une démonstration personnalisée avec l'un de nos experts RH et découvrez comment RH-Flow peut transformer votre gestion.</p>
                        <a href="#demo" class="inline-flex items-center bg-accent text-white px-6 py-3 rounded-lg hover:bg-accent/90 transition-colors font-bold">
                            <span>Demander une démo</span>
                            <i class="ri-arrow-right-line ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gradient-to-br from-gray-900 to-gray-800 text-white pt-16 pb-8">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
                <!-- Company Info -->
                <div class="lg:col-span-2">
                    <div class="flex items-center space-x-3 mb-6">
                        <img src="{{ asset('img/logos/logo-light.png') }}" width="120px" alt="RH-Flow" class="h-10 w-auto">
                        <span class="text-2xl font-bold text-white">RH-Flow</span>
                    </div>
                    <p class="text-gray-300 mb-6 leading-relaxed">
                        La solution RH complète pour les entreprises ivoiriennes. Automatisez, optimisez et transformez votre gestion des ressources humaines avec notre plateforme moderne et intuitive.
                    </p>
                    
                    <div class="bg-primary/10 rounded-xl p-4 border border-primary/20">
                        <div class="flex items-center">
                            <i class="ri-phone-line text-primary mr-3 text-xl"></i>
                            <div>
                                <p class="font-semibold text-white">Support client</p>
                                <p class="text-gray-300">+225 07 67 13 19 93</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Products -->
                <div>
                    <h3 class="text-lg font-bold mb-6 text-white">Produit</h3>
                    <ul class="space-y-3">
                        <li><a href="#fonctionnalites" class="text-gray-300 hover:text-primary transition-colors">Fonctionnalités</a></li>
                        <li><a href="#tarifs" class="text-gray-300 hover:text-primary transition-colors">Tarifs</a></li>
                        <li><a href="#temoignages" class="text-gray-300 hover:text-primary transition-colors">Témoignages</a></li>
                        <li><a href="#faq" class="text-gray-300 hover:text-primary transition-colors">FAQ</a></li>
                        <li><a href="#demo" class="text-gray-300 hover:text-primary transition-colors">Démo</a></li>
                    </ul>
                </div>

                <!-- Resources -->
                <div>
                    <h3 class="text-lg font-bold mb-6 text-white">Ressources</h3>
                    <ul class="space-y-3">
                        <li><a href="{{route('privacy') }}" class="text-gray-300 hover:text-primary transition-colors">Confidentialité</a></li>
                        <li><a href="#avantages" class="text-gray-300 hover:text-primary transition-colors">Avantages</a></li>
                        <li><a href="{{route('simulateur') }}" class="text-gray-300 hover:text-primary transition-colors">Simulateur</a></li>
                        <li><a href="#contact" class="text-gray-300 hover:text-primary transition-colors">Contact</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-primary transition-colors">Blog</a></li>
                    </ul>
                </div>
            </div>

            <!-- Bottom Footer -->
            <div class="border-t border-gray-700 pt-8">
                <div class="flex flex-col lg:flex-row justify-between items-center">
                    <div class="mb-4 lg:mb-0">
                        <p class="text-gray-400">© 2025 RH-Flow. Tous droits réservés.</p>
                        <p class="text-gray-500 text-sm mt-1">Solution RH pour les entreprises ivoiriennes</p>
                    </div>
                    <div class="flex flex-wrap items-center space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">Mentions légales</a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">Politique de confidentialité</a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">CGU</a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">Paiement sécurisé</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script>
        function showMonthlyPlans() {
            const plans = document.querySelectorAll('#plans-container > div');
            const monthlyBtn = document.getElementById('monthly-btn');
            const yearlyBtn = document.getElementById('yearly-btn');
            const discountMessage = document.getElementById('yearly-discount-message');
            
            // Mettre à jour les styles des boutons
            monthlyBtn.className = 'bg-blue-700 text-white px-8 py-3 rounded-lg hover:bg-blue-800 transition-colors font-medium';
            yearlyBtn.className = 'bg-gray-200 text-gray-700 px-8 py-3 rounded-lg hover:bg-gray-300 transition-colors font-medium';
            
            // Masquer le message de réduction
            discountMessage.classList.add('hidden');
            
            // Afficher/masquer les plans selon le prix mensuel
            plans.forEach(plan => {
                const planPrice = parseFloat(plan.dataset.price || '0');
                const planId = parseInt(plan.dataset.id || '0');
                
                // Afficher tous les plans sauf Pro Master (150000) et Pro Day (600000) pour le mois
                if (planPrice === 0 || planPrice === 5000 || planPrice === 10000 || planPrice === 20000 || planPrice === 35000 || planPrice === 50000) {
                    plan.style.display = 'flex';
                    plan.style.animation = 'fadeIn 0.3s ease-in-out';
                    
                    // Afficher uniquement les prix mensuels
                    const monthlyPrices = plan.querySelectorAll('.monthly-price');
                    const yearlyPrices = plan.querySelectorAll('.yearly-price');
                    const monthlyPeriods = plan.querySelectorAll('.monthly-period');
                    const yearlyPeriods = plan.querySelectorAll('.yearly-period');
                    
                    monthlyPrices.forEach(el => el.style.display = 'inline');
                    yearlyPrices.forEach(el => el.style.display = 'none');
                    monthlyPeriods.forEach(el => el.style.display = 'inline');
                    yearlyPeriods.forEach(el => el.style.display = 'none');
                } else {
                    plan.style.display = 'none';
                }
            });
        }

        function showYearlyPlans() {
            const plans = document.querySelectorAll('#plans-container > div');
            const monthlyBtn = document.getElementById('monthly-btn');
            const yearlyBtn = document.getElementById('yearly-btn');
            const discountMessage = document.getElementById('yearly-discount-message');
            
            // Mettre à jour les styles des boutons
            yearlyBtn.className = 'bg-blue-700 text-white px-8 py-3 rounded-lg hover:bg-blue-800 transition-colors font-medium';
            monthlyBtn.className = 'bg-gray-200 text-gray-700 px-8 py-3 rounded-lg hover:bg-gray-300 transition-colors font-medium';
            
            // Afficher le message de réduction
            discountMessage.classList.remove('hidden');
            discountMessage.style.animation = 'fadeIn 0.3s ease-in-out';
            
            // Afficher/masquer les plans selon le prix annuel
            plans.forEach(plan => {
                const planPrice = parseFloat(plan.dataset.price || '0');
                const planId = parseInt(plan.dataset.id || '0');
                const planPriceYearly = parseFloat(plan.dataset.priceYearly || '0');
                
                // Afficher tous les plans y compris Pro Master et Pro Day pour l'année
                if (planPriceYearly > 0 || planPrice === 0) {
                    plan.style.display = 'flex';
                    plan.style.animation = 'fadeIn 0.3s ease-in-out';
                    
                    // Afficher uniquement les prix annuels
                    const monthlyPrices = plan.querySelectorAll('.monthly-price');
                    const yearlyPrices = plan.querySelectorAll('.yearly-price');
                    const monthlyPeriods = plan.querySelectorAll('.monthly-period');
                    const yearlyPeriods = plan.querySelectorAll('.yearly-period');
                    
                    monthlyPrices.forEach(el => el.style.display = 'none');
                    yearlyPrices.forEach(el => el.style.display = 'inline');
                    monthlyPeriods.forEach(el => el.style.display = 'none');
                    yearlyPeriods.forEach(el => el.style.display = 'inline');
                } else {
                    plan.style.display = 'none';
                }
            });
        }

        // Initialiser l'affichage mensuel au chargement
        document.addEventListener('DOMContentLoaded', function() {
            showMonthlyPlans();
        });

        // Ajouter les styles d'animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
        `;
        document.head.appendChild(style);
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Mobile menu toggle
            const menuButton = document.querySelector('.md\\:hidden');
            const mobileMenu = document.createElement('div');
            mobileMenu.className = 'fixed inset-0 bg-white z-50 transform translate-x-full transition-transform duration-300 ease-in-out';
            mobileMenu.innerHTML = `
                <div class="flex justify-between items-center p-4 border-b">
                    <span class="text-primary font-['Pacifico'] text-2xl">RH-Flow</span>
                    <button class="w-10 h-10 flex items-center justify-center text-gray-700">
                        <i class="ri-close-line ri-xl"></i>
                    </button>
                </div>
                <nav class="p-4">
                    <ul class="space-y-4">
                        <li><a href="#fonctionnalites" class="block py-2 text-gray-700 hover:text-primary font-medium">Fonctionnalités</a></li>
                        <li><a href="#avantages" class="block py-2 text-gray-700 hover:text-primary font-medium">Avantages</a></li>
                        <li><a href="#tarifs" class="block py-2 text-gray-700 hover:text-primary font-medium">Tarifs</a></li>
                        <li><a href="#contact" class="block py-2 text-gray-700 hover:text-primary font-medium">Contact</a></li>
                        <li class="pt-4 border-t"><a href="#" class="block py-2 text-gray-700 hover:text-primary font-medium">Se connecter</a></li>
                        <li><a href="#contact" class="block py-2 bg-primary text-white px-6 py-2 rounded-button text-center">Demander une démo</a></li>
                    </ul>
                </nav>
            `;
            document.body.appendChild(mobileMenu);

            menuButton.addEventListener('click', function() {
                mobileMenu.classList.remove('translate-x-full');
            });

            const closeButton = mobileMenu.querySelector('button');
            closeButton.addEventListener('click', function() {
                mobileMenu.classList.add('translate-x-full');
            });

            // Close mobile menu when clicking on links
            const mobileLinks = mobileMenu.querySelectorAll('a');
            mobileLinks.forEach(link => {
                link.addEventListener('click', function() {
                    mobileMenu.classList.add('translate-x-full');
                });
            });
        });
        function checkout() {
            CinetPay.setConfig({
                apikey: '291038086662625fc7026f9.57751076',//   YOUR APIKEY
                site_id: '5871268',//YOUR_SITE_ID
                notify_url: 'https://dc-knowing.com/RH-Flow/',
                mode: 'PRODUCTION'
            });
            CinetPay.getCheckout({
                transaction_id: Math.floor(Math.random() * 100000000).toString(), // YOUR TRANSACTION ID
                amount: 5000,
                currency: 'XOF',
                channels: 'MOBILE_MONEY',
                description: 'Paiement du pack BASIC',
            });
            CinetPay.waitResponse(function(data) {
                if (data.status == "REFUSED") {
                    if (alert("Votre paiement a échoué")) {
                        window.location.reload();
                    }
                } else if (data.status == "ACCEPTED") {
                    if (alert("Votre paiement a été effectué avec succès")) {
                        window.location.href = "https://dc-knowing.com/RH-Flow/register/2";
                    }
                }
            });
            CinetPay.onError(function(data) {
                console.log(data);
            });
        }
        function checkout1() {
            CinetPay.setConfig({
                apikey: '291038086662625fc7026f9.57751076',//   YOUR APIKEY
                site_id: '5871268',//YOUR_SITE_ID
                notify_url: 'https://dc-knowing.com/RH-Flow/',
                mode: 'PRODUCTION'
            });
            CinetPay.getCheckout({
                transaction_id: Math.floor(Math.random() * 100000000).toString(), // YOUR TRANSACTION ID
                amount: 10000,
                currency: 'XOF',
                channels: 'MOBILE_MONEY',
                description: 'Paiement du pack PRO',
            });
            CinetPay.waitResponse(function(data) {
                if (data.status == "REFUSED") {
                    if (alert("Votre paiement a échoué")) {
                        window.location.reload();
                    }
                } else if (data.status == "ACCEPTED") {
                    if (alert("Votre paiement a été effectué avec succès")) {
                        window.location.href = "https://dc-knowing.com/RH-Flow/register/3";
                    }
                }
            });
            CinetPay.onError(function(data) {
                console.log(data);
            });
        }
        function checkout2() {
            CinetPay.setConfig({
                apikey: '291038086662625fc7026f9.57751076',//   YOUR APIKEY
                site_id: '5871268',//YOUR_SITE_ID
                notify_url: 'https://dc-knowing.com/RH-Flow/',
                mode: 'PRODUCTION'
            });
            CinetPay.getCheckout({
                transaction_id: Math.floor(Math.random() * 100000000).toString(), // YOUR TRANSACTION ID
                amount: 50000,
                currency: 'XOF',
                channels: 'MOBILE_MONEY',
                description: 'Paiement du pack PRO MAX',

            });
            CinetPay.waitResponse(function(data) {
                if (data.status == "REFUSED") {
                    if (alert("Votre paiement a échoué")) {
                        window.location.reload();
                    }
                } else if (data.status == "ACCEPTED") {
                    if (alert("Votre paiement a été effectué avec succès")) {
                        window.location.href = "https://dc-knowing.com/RH-Flow/register/8";
                    }
                }
            });
            CinetPay.onError(functin(data) {
                console.log(data);
            });
        }
    </script>
</body>
</html>

                 